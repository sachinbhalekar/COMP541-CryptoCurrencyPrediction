from pytrends.request import TrendReq
import codecs
import pandas as pd

# Login to Google. Only need to run this once, the rest of requests will use the same session.
pytrend = TrendReq()

# Create payload and capture API tokens. Only needed for interest_over_time(), interest_by_region() & related_queries()
pytrend.build_payload(kw_list=['bitcoin'])


kw_list=['bitcoin']
historicaldata_df = pytrend.get_historical_interest(kw_list, year_start=2014, month_start=6, day_start=1, hour_start=0, year_end=2014, month_end=7, day_end=3, hour_end=0, cat=0, geo='', gprop='', sleep=0)

#print(historicaldata_df.describe(include = 'all'))
#print(historicaldata_df.head())
outputFile = codecs.open("Output_2012_to_2014_hourly.csv", "w+", "utf-8")
df = pd.DataFrame(historicaldata_df)
#print(df)
for  index, row in df.iterrows():
    outputFile.write(('\n%s,%s,%s' % (index, row[0], row[1])))
    #print(index)