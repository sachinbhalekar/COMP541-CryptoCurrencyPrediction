# importing csv module 
import csv 
import scipy.stats
from datetime import datetime
from datetime import timedelta
import calendar
from dateutil.relativedelta import *
import numpy as np

# csv file name 

  
# initializing the titles and rows list 

close = []
Trend = [] 


filename = 'DayAvgSearchNotNormalizedReduced.csv'
# reading csv file ,0.0,0.0,0.0,0.0,0.0,0.0,0.0
with open(filename, 'r') as csvfile: 
    csvreader = csv.reader(csvfile) 
    
    prev = csvreader.next() 
    
    for row in csvreader: 
        Trend.append(float(row[5]))
        close.append(float(row[7]))
    
print('\nPearson Corelation between BTC Close and Search Volume')   
print(scipy.stats.pearsonr(close, Trend))


#print('\nPearson Corelation between Opening Bitcoin Price and Search Volume')    
#print(scipy.stats.pearsonr(Price_open, Trend))

#print('\nPearson Corelation between Average Bitcoin Price and Search Volume')    
#print(scipy.stats.pearsonr(Price_avg, Trend))
  
#print('\nPearson Corelation between Search Percentage and Search Volume')    
#print(scipy.stats.pearsonr(Trend_Percent, Trend))