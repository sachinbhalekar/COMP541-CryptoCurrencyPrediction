# importing csv module 
import csv 
import scipy.stats
from datetime import datetime
from datetime import timedelta
import calendar
from dateutil.relativedelta import *
import numpy as np

# csv file name 
filename = "BTC_DATA.csv"
  
# initializing the titles and rows list 
prev = [] 
Price_close = [] 
Price_open = [] 
Price_avg = []
prev_7_avg = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
close = []
Trend = [] 
Trend_Percent = []

filename = 'INTEGRATED_DATA_WITHOUT_MISSING_VALUES.csv'
# reading csv file ,0.0,0.0,0.0,0.0,0.0,0.0,0.0
with open(filename, 'r') as csvfile: 
    with open('DayAvgSearchNotNormalized.csv', 'w+b') as csvoutput:
        # creating a csv reader object 
        csvreader = csv.reader(csvfile) 
        writer = csv.writer(csvoutput, lineterminator='\n')
        # extracting field names through first row 
        prev = csvreader.next() 
        prev = csvreader.next()
        prev_7_avg[0]=float(prev[9])

        prev = csvreader.next()
        prev_7_avg[1]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[2]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[3]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[4]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[5]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[6]=float(prev[9])


        prev = csvreader.next()
        prev_7_avg[7]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[8]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[9]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[10]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[11]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[12]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[13]=float(prev[9])

        prev = csvreader.next()
        prev_7_avg[14]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[15]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[16]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[17]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[18]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[19]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[20]=float(prev[9])
        
        prev = csvreader.next()
        prev_7_avg[21]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[22]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[23]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[24]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[25]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[26]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[27]=float(prev[9])
        
        prev = csvreader.next()
        prev_7_avg[28]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[29]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[30]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[31]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[32]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[33]=float(prev[9])
        prev = csvreader.next()
        prev_7_avg[34]=float(prev[9])
        
    
    
        #print(np.mean(prev_7_avg))
        # extracting each data row one by one 
        i=0
        all = []
        print('Date,Open,High,Low,Close,TotalSearch,Avg_5WeekSearch')
        for row in csvreader: 
            
            #Price_avg.append((float(row[4]) + float(row[5]) + float(row[6]) + float(row[7]) ) / 4)
            Trend.append(np.mean(prev_7_avg))
            close.append(float(row[5]) )
            #Trend_Percent.append(float(prev[8]) )
            row.append(np.mean(prev_7_avg))
            all.append(row)
           # print(row)
          #Date,Symbol,Open,High,Low,Close,Volume,MarketCap,PercentSearch,TotalSearch
            print(('%s,%s,%s,%s,%s,%s,%s' % (row[0],row[2],row[3], row[4],row[5],row[9],np.mean(prev_7_avg))))
            #print(index)
            prev_7_avg[i%35] = float(row[9])
            i=i+1

        #writer.writerows(all)

#print('\nPearson Corelation between BTC Close and Search Volume')    
#print(scipy.stats.pearsonr(close, Trend))

#print('\nPearson Corelation between Opening Bitcoin Price and Search Volume')    
#print(scipy.stats.pearsonr(Price_open, Trend))

#print('\nPearson Corelation between Average Bitcoin Price and Search Volume')    
#print(scipy.stats.pearsonr(Price_avg, Trend))
  
#print('\nPearson Corelation between Search Percentage and Search Volume')    
#print(scipy.stats.pearsonr(Trend_Percent, Trend))