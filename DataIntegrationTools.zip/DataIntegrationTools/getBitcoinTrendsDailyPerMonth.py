from pytrends.request import TrendReq
import codecs
import pandas as pd
from datetime import datetime
from datetime import timedelta
import calendar
from dateutil.relativedelta import *

# Login to Google. Only need to run this once, the rest of requests will use the same session.
pytrend = TrendReq()

# Create payload and capture API tokens. Only needed for interest_over_time(), interest_by_region() & related_queries()

datetime_Sinceobject = datetime.strptime('2018-09-01','%Y-%m-%d')
datetime_Untilobject = datetime.strptime('2018-10-01','%Y-%m-%d')

while True:
    

    first_day = datetime_Sinceobject.replace(day = 1)
    last_day = datetime_Sinceobject.replace(day = calendar.monthrange(datetime_Sinceobject.year, datetime_Sinceobject.month)[1])

    frame = first_day.strftime('%Y-%m-%d') + ' ' + last_day.strftime('%Y-%m-%d')
    datetime_Sinceobject+= relativedelta(months=+1)
    print(frame)

    if datetime_Sinceobject > datetime_Untilobject:
        break
    pytrend.build_payload(kw_list=['bitcoin'],timeframe= frame)


    kw_list=['bitcoin']
    historicaldata_df = pytrend.interest_over_time()

    filename_ = first_day.strftime('%Y-%m') + '_Data' + '.csv'
    outputFile = codecs.open(filename_, "w+", "utf-8")
    df = pd.DataFrame(historicaldata_df)
    #print(df)
    for  index, row in df.iterrows():
        outputFile.write(('\n%s,%s,%s' % (index, row[0], row[1])))
        #print(index)