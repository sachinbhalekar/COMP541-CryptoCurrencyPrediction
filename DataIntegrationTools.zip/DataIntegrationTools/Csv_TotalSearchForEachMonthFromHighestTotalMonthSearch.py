# importing csv module 
import csv 
  
# csv file name 
filename = "Monthly_Data.csv"
  
# initializing the titles and rows list 
fields = [] 
rows = [] 
  
# reading csv file 
with open(filename, 'r') as csvfile: 
    # creating a csv reader object 
    csvreader = csv.reader(csvfile) 
      
    # extracting field names through first row 
    fields = csvreader.next() 
 # extracting each data row one by one 
    for row in csvreader: 
        rows.append(row) 
  
    # get total number of rows 
    print("Total no. of rows: %d"%(csvreader.line_num)) 
  
# printing the field names 
print('Field names are:' + ', '.join(field for field in fields)) 


#Average counted for last 12 months
HighestMonthSearch = 40000000.0

#Total Search for 12 month

print(HighestMonthSearch)

print('Total Search per Month')

import codecs
outputFile = codecs.open('TotalSearchAllMonths.csv', "w+", "utf-8")
for row in rows[:]: 
    # parsing each column of a row
    monthlySearch = (int(row[1])/100.0) * HighestMonthSearch
    outputFile.write(('\n%s,%s,%f' % (row[0], row[1], monthlySearch )))
    print(monthlySearch), 
    print('\n') 




