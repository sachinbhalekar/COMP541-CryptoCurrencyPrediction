# importing csv module 
import csv 
  
# csv file name 
filename = "TotalSearchAllMonths.csv"
  
# initializing the titles and rows list 
fields = [] 
rows = [] 
import codecs
fileThis_ = 'GTRENDS_DATA.csv'
outputFileFinal = codecs.open(fileThis_ , "w+", "utf-8")  
# reading csv file 
with open(filename, 'r') as csvfile: 
    # creating a csv reader object 
    csvreader = csv.reader(csvfile) 
      
    # extracting field names through first row 
    fields = csvreader.next() 
  
    # extracting each data row one by one 
    for row in csvreader: 
        rows.append(row) 
  
    # get total number of rows 
    print("Total no. of rows: %d"%(csvreader.line_num)) 
  
# printing the field names 
print('Field names are:' + ', '.join(field for field in fields)) 
  
#  printing first 5 rows 

#print('\nFirst 5 rows are:\n') 
for row in rows[:]: 
    fields1 = [] 
    rows1 = [] 
    # parsing each column of a row
    filename1 = '_' + row[0] + '_TotalSearch.csv'
    print(filename1)
    with open(filename1, 'r') as csvfile1: 
    # creating a csv reader object 
        csvreader1 = csv.reader(csvfile1) 
      
    # extracting field names through first row 
        fields1 = csvreader1.next() 
    
    
  
    # extracting each data row one by one 
        for row1 in csvreader1: 
            rows1.append(row1) 
  
    # get total number of rows 
    print("Total no. of rows: %d"%(csvreader1.line_num))
    
    
    for row1 in rows1[:]: 
    # parsing each column of a row
        outputFileFinal.write(('\n%s,%s,%s' % (row1[0], row1[1], row1[2] )))




