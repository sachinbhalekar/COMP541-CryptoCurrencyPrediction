from pytrends.request import TrendReq
import codecs
import pandas as pd
from datetime import datetime
from datetime import timedelta
import calendar
from dateutil.relativedelta import *

# Login to Google. Only need to run this once, the rest of requests will use the same session.
pytrend = TrendReq()

# Create payload and capture API tokens. Only needed for interest_over_time(), interest_by_region() & related_queries()

datetime_Sinceobject = datetime.strptime('2013-01-01','%Y-%m-%d')
datetime_Untilobject = datetime.strptime('2018-09-01','%Y-%m-%d')
filename_ = 'Monthly' + '_Data' + '.csv'
outputFile = codecs.open(filename_, "w+", "utf-8")
while True:
    

    first_day = datetime_Sinceobject.replace(day = 1)
    last_day = datetime_Sinceobject.replace(day = calendar.monthrange(datetime_Sinceobject.year, datetime_Sinceobject.month)[1])

    datetime_Sinceobject+= relativedelta(months=+1)
    print(first_day.strftime('%Y-%m'))

    if datetime_Sinceobject > datetime_Untilobject:
        break
   
    outputFile.write(('\n%s,' % (first_day.strftime('%Y-%m'))))
    