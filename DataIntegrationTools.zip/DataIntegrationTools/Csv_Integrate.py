# importing csv module 
import csv 
from datetime import datetime
from datetime import timedelta
import calendar
from dateutil.relativedelta import *
# csv file name 
filename = "BTC_DATA.csv"
  
# initializing the titles and rows list 
fields = [] 
rows = [] 
import codecs
fileThis_ = 'INTEGRATED_DATA_WITHOUT_MISSING_VALUES.csv'
outputFileFinal = codecs.open(fileThis_ , "w+", "utf-8")  
# reading csv file 
with open(filename, 'r') as csvfile: 
    # creating a csv reader object 
    csvreader = csv.reader(csvfile) 
      
    # extracting field names through first row 
    fields = csvreader.next() 
  
    # extracting each data row one by one 
    for row in csvreader: 
        rows.append(row) 
  
    # get total number of rows 
    print("Total no. of rows: %d"%(csvreader.line_num)) 
  
# printing the field names 
print('Field names are:' + ', '.join(field for field in fields)) 
  
fields1 = [] 
rows1 = [] 
    # parsing each column of a row
filename1 = 'GTRENDS_DATA.csv'
print(filename1)
with open(filename1, 'r') as csvfile1: 
    # creating a csv reader object 
     csvreader1 = csv.reader(csvfile1) 
      
    # extracting field names through first row 
     fields1 = csvreader1.next() 
    
    # extracting each data row one by one 
     for row1 in csvreader1: 
        rows1.append(row1) 
  
    # get total number of rows 
     print("Total no. of rows: %d"%(csvreader1.line_num)) 
# printing the field names 
print('Field names are:' + ', '.join(field for field in fields1)) 

for row1 in rows1[:]: 
    datetime_object1 = datetime.strptime(row1[0],'%Y-%m-%d %H:%M:%S')
    #print( datetime_object1.strftime('%Y-%m-%d'))
    found = 0
    for row in rows[:]: 
         datetime_object = datetime.strptime(row[1],'%m/%d/%Y')
         if datetime_object == datetime_object1:
             print( datetime_object.strftime('%Y-%m-%d'))
             found = 1
             outputFileFinal.write(('\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s' % (datetime_object1.strftime('%Y-%m-%d'),row[2],row[3],row[4],row[5],row[6],row[7],row[8],row1[1], row1[2] )))
             break
    #if found == 0:
        #outputFileFinal.write(('\n%s,%s,%s,%s,%s,%s,%s,%s,%s,%s' % (datetime_object1.strftime('%Y-%m-%d'),'','','','','','','',row1[1], row1[2])))

